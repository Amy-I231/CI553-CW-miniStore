package clients.customer;
import java.util.*;

public class NamesForSearching extends HashMap<String, String> {
	
	private static final long serialVersionUID = -987521528562117805L;

	NamesForSearching(){   //putting everything in a hashmap for accessing later
		put("0001", "TV");
		put("0002", "Radio");
		put("0003", "Toaster");
		put("0004", "Watch");
		put("0005", "Camera");
		put("0006", "Music player");
		put("0007", "USB drive");
	}
	
	public <K, V> K getName(Map<K, V> map,  V value) {  //creates the getName method used in the customer controller
		for  (Entry<K, V> entry : map.entrySet() ) {  //for each key in the map
			if (Objects.equals(value,  entry.getValue())) {  //check if the value put in is the same as a value from the map
				return entry.getKey();  // if so then return the key AKA name
			}
		} 
 		return null;  //if not found then dont return anything
	}
}
