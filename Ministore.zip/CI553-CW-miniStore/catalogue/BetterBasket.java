package catalogue;

import java.io.Serializable;
import java.util.Collections;

/**
 * This code makes the basket better by making duplicate purchases 
 * add to a quantity marker and not take up space.
 * Also helps sort items in the basket by order number
 * 
 * @author  Amy Ingram
 * @version 1.0
 */
public class BetterBasket extends Basket implements Serializable
{
  private static final long serialVersionUID = 1L;
  
  @Override
  public boolean add( Product pr )
  {                              
    for(Product prList : this) {
    	if(prList.getProductNum().equals(pr.getProductNum())) {
    		int quantity = pr.getQuantity() + prList.getQuantity();
    		prList.setQuantity(quantity);
    		return (true);
    	}
    }
	 super.add( pr );//Adds the product after being merged into the basket
	 Collections.sort(this); //connects up with the "compareTo" function at the bottom of Product.java
	 return(true);
  }
  
  
  
}
