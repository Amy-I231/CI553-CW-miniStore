package catalogue;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class BetterBasketTest {

	@Test
	void testMergeProduct() {
		BetterBasket br = new BetterBasket();
		Product p1 = new Product("0001","Lightbulb",5.2, 1);
		Product p2 = new Product("0002","Oven",345.5, 1);
		br.add(p1);
		br.add(p2);
		br.add(p2);
		System.out.println(br);
		assertEquals(2,br.size(),"incorrect size when merged");
		assertEquals(2,br.get(1).getQuantity(),"incorrect quantity when merged");
	}
	
	@Test
	void testSortProduct(){
		BetterBasket br = new BetterBasket();
		Product p1 = new Product("0004","Lightbulb",5.2, 1);
		Product p2 = new Product("0002","Oven",345.5, 1);
		Product p3 = new Product("0003","Microwave",100.4, 1);
		Product p4 = new Product("0001","Cutlery Set",20.3, 1);
		br.add(p1);
		br.add(p2);
		br.add(p3);
		br.add(p4);
		System.out.println(br);
		assertEquals("0001",br.get(0).getProductNum(),"not sorted");
	}
	
}
